<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <title>Premier exercice PHP</title>
        <meta charset="UTF-8" />
        <link rel="stylesheet" href="iniPHP.css" />
    </head>
    <body>
        <header>
            <h1>Premier exercice PHP</h1>
            <h2>Réalisé par <span class="nom">Aboubakar Diakite</span></h2>
        </header>
        
        
        <section>
            <h2>Exercice 1</h2>
                <h3>Question 1.</h3>


                <h3>Question 2.</h3>
        </section>
        <section>
            <h2>Exercice 2</h2>

        
        
        </section>
        <section>
            <h2>Exercice 3</h2>
                <h3>Question 1.</h3>


                <h3>Question 2.</h3>





                <h3>Question 3.</h3>


        </section>
       
    </body>
    
</html>
